// app/(tabs)/assistant.tsx
import React, { useRef, useState, useEffect } from 'react';
import { StyleSheet, View, TouchableOpacity, Text, Dimensions } from 'react-native';
import * as Speech from 'expo-speech';
import Svg, { Circle, Rect, Path } from 'react-native-svg';

export default function AssistantScreen() {
  const [listening, setListening] = useState(false);
  const [mouthState, setMouthState] = useState('closed'); // 'closed', 'open', 'talking'

  // Update mouth state based on the listening state
  useEffect(() => {
    if (listening) {
      // Start mouth animation when speech begins
      setMouthState('talking');
    } else {
      // Reset mouth state when finished speaking or not listening
      setMouthState('closed');
    }
  }, [listening]);

  const handleListen = () => {
    if (listening) return;
    setListening(true);
    const dummyResponse = "I am here to help you with CivicConnect. How can I assist you today?";

    // Start dummy speech and change the mouth state when speaking
    Speech.speak(dummyResponse, {
      onStart: () => setMouthState('talking'),  // Mouth is talking when speech starts
      onDone: () => {
        setListening(false);
        setMouthState('closed');  // Reset mouth to closed when speech ends
      },
      onError: () => setMouthState('closed')  // Reset on error
    });
  };

  return (
    <View style={styles.container}>
      {/* Robot Face using SVG */}
      <Svg width={Dimensions.get('window').width * 0.8} height={Dimensions.get('window').width * 0.8}>
        {/* Robot Head */}
        <Rect x="50" y="50" width="200" height="200" rx="30" ry="30" fill="#A9A9A9" />
        
        {/* Robot Eyes */}
        <Circle cx="120" cy="120" r="15" fill="white" />
        <Circle cx="180" cy="120" r="15" fill="white" />
        
        {/* Robot Pupils */}
        <Circle cx="120" cy="120" r="5" fill="black" />
        <Circle cx="180" cy="120" r="5" fill="black" />
        
        {/* Robot Mouth with animation */}
        {mouthState === 'closed' && (
          <Rect x="120" y="180" width="60" height="20" rx="10" ry="10" fill="black" />
        )}
        {mouthState === 'open' && (
          <Rect x="120" y="180" width="60" height="10" rx="5" ry="5" fill="black" />
        )}
        {mouthState === 'talking' && (
          <Path
            d="M 120 190 Q 150 210, 180 190"
            stroke="black"
            strokeWidth="5"
            fill="transparent"
          />
        )}
      </Svg>

      <TouchableOpacity
        style={[styles.button, listening && styles.listening]}
        onPress={handleListen}>
        <Text style={styles.buttonText}>{listening ? 'Listening...' : 'Start Listening'}</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#121212', // Dark background for a professional look.
    justifyContent: 'center',
    alignItems: 'center',
  },
  button: {
    position: 'absolute',
    bottom: 40,
    backgroundColor: '#1E90FF',
    paddingVertical: 15,
    paddingHorizontal: 30,
    borderRadius: 25,
  },
  listening: {
    backgroundColor: '#FF6347',
  },
  buttonText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: 'bold',
  },
});