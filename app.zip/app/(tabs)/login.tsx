import React, { useState } from 'react';
import { View, TextInput, TouchableOpacity, StyleSheet, Alert } from 'react-native';
import { useRouter } from 'expo-router';
import axios from 'axios'; // Import axios for making API requests
import { ThemedText } from '@/components/ThemedText';
import { ThemedView } from '@/components/ThemedView';

export default function LoginScreen() {
  const router = useRouter();
  const [aadharNo, setAadharNo] = useState(''); // Aadhar number
  const [password, setPassword] = useState(''); // Password

  // Handle login on button press
  const handleLogin = async () => {
    // Validate inputs
    if (!aadharNo || !password) {
      return Alert.alert('Error', 'Please enter both Aadhar number and password.');
    }

    try {
      // Make POST request to backend login API
      const response = await axios.post('http://192.168.0.109:5000/login', {
        aadhar_no: aadharNo,
        password: password,
      });

      // If login is successful, navigate to the home screen (or any other screen)
      if (response.data.success) {
        Alert.alert('Success', 'Login successful!');
        router.replace('/(tabs)'); // Navigate to your app's main screen
      } else {
        // Handle invalid login
        Alert.alert('Error', response.data.message || 'Invalid credentials');
      }
    } catch (error) {
      console.error('Login error:', error);
      Alert.alert('Error', 'Something went wrong. Please try again.');
    }
  };

  return (
    <ThemedView style={styles.container}>
      <ThemedText type="title">Log-in to CivicConnect</ThemedText>

      {/* Aadhar number input field */}
      <TextInput
        style={styles.input}
        placeholder="Aadhar Number"
        value={aadharNo}
        keyboardType="numeric"
        onChangeText={setAadharNo}
      />

      {/* Password input field */}
      <TextInput
        style={styles.input}
        placeholder="Password"
        value={password}
        secureTextEntry
        onChangeText={setPassword}
      />

      {/* Login button */}
      <TouchableOpacity style={styles.button} onPress={handleLogin}>
        <ThemedText style={styles.buttonText}>Login</ThemedText>
      </TouchableOpacity>

      {/* Link to navigate to the register screen */}
      <TouchableOpacity onPress={() => router.push('/register')}>
        <ThemedText style={styles.linkText}>
          Don't have an account? Click to register.
        </ThemedText>
      </TouchableOpacity>
    </ThemedView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
    justifyContent: 'center',
    backgroundColor: '#fff',
  },
  input: {
    height: 50,
    borderColor: '#ddd',
    borderWidth: 1,
    marginBottom: 15,
    marginTop: 5,
    borderRadius: 8,
    paddingHorizontal: 10,
  },
  button: {
    backgroundColor: '#1E90FF',
    padding: 15,
    borderRadius: 8,
    alignItems: 'center',
  },
  buttonText: {
    color: '#fff',
    fontSize: 16,
  },
  linkText: {
    marginTop: 15,
    color: '#1E90FF',
    fontSize: 14,
    textAlign: 'center',
  },
});
