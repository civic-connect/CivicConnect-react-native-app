import React, { useState } from 'react';
import { View, TextInput, TouchableOpacity, StyleSheet, Alert } from 'react-native';
import { useRouter } from 'expo-router';
import { ThemedText } from '@/components/ThemedText';
import { ThemedView } from '@/components/ThemedView';
import axios from 'axios';

export default function RegisterScreen() {
  const router = useRouter();
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [role, setRole] = useState('');
  const [proofDocument, setProofDocument] = useState('');
  const [aadharNo, setAadharNo] = useState('');

  // Handle the registration request
  const handleRegister = async () => {
    if (!name || !email || !password || !role || !proofDocument || !aadharNo) {
      Alert.alert('Error', 'All fields are required!');
      return;
    }

    try {
      const response = await axios.post('http://192.168.0.109:5000/register', {
        name,
        email,
        password,
        role,
        proof_document: proofDocument,
        aadhar_no: aadharNo,
      });

      if (response.data.success) {
        Alert.alert('Success', 'Registration successful!');
        router.replace('/login');
      } else {
        Alert.alert('Error', response.data.message);
      }
    } catch (error) {
      console.error(error);
      Alert.alert('Error', 'An error occurred while registering. Please try again later.');
    }
  };

  return (
    <ThemedView style={styles.container}>
      <ThemedText type="title">Register on CivicConnect</ThemedText>

      <TextInput
        style={styles.input}
        placeholder="Full Name"
        value={name}
        onChangeText={setName}
      />
      <TextInput
        style={styles.input}
        placeholder="Email"
        value={email}
        autoCapitalize="none"
        keyboardType="email-address"
        onChangeText={setEmail}
      />
      <TextInput
        style={styles.input}
        placeholder="Password"
        value={password}
        secureTextEntry
        onChangeText={setPassword}
      />
      <TextInput
        style={styles.input}
        placeholder="Role"
        value={role}
        onChangeText={setRole}
      />
      <TextInput
        style={styles.input}
        placeholder="Proof Document"
        value={proofDocument}
        onChangeText={setProofDocument}
      />
      <TextInput
        style={styles.input}
        placeholder="Aadhar Number"
        value={aadharNo}
        keyboardType="numeric"
        onChangeText={setAadharNo}
      />

      <TouchableOpacity style={styles.button} onPress={handleRegister}>
        <ThemedText style={styles.buttonText}>Register</ThemedText>
      </TouchableOpacity>

      <TouchableOpacity onPress={() => router.push('/login')}>
        <ThemedText style={styles.linkText}>
          Already a registered user? Click to login.
        </ThemedText>
      </TouchableOpacity>
    </ThemedView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
    paddingTop: 50,
    backgroundColor: '#fff',
  },
  input: {
    height: 50,
    borderColor: '#ddd',
    borderWidth: 1,
    marginBottom: 15,
    marginTop: 5,
    borderRadius: 8,
    paddingHorizontal: 10,
  },
  button: {
    backgroundColor: '#32CD32',
    padding: 15,
    borderRadius: 8,
    alignItems: 'center',
  },
  buttonText: {
    color: '#fff',
    fontSize: 16,
  },
  linkText: {
    marginTop: 15,
    color: '#1E90FF',
    fontSize: 14,
    textAlign: 'center',
  },
});
